const asyncHandler = require('express-async-handler')

module.exports = {
  Guard: () => {}
  // Guard: asyncHandler(async (req, res, next) => {next()}),
}
