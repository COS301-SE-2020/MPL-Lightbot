# LightBot_Server
This will serve as the base of the server application for the 
lightbot ai adaptive traffic solution

